import React from "react";
import ReactDOM from "react-dom";

import "./styles.css";

const Todo = props => (
  <li>
    <intput type='checkbox'/>
    <button> Delete Me </button>
    <span>{props.text}</span>
  </li>
)

class App extends React.Component {
  constructor(){
    super();
    this.state = {
      todos: []
    }
  }

  addTodo(){
    const text = prompt("Add Todo text; ")
    this.setState({
      todos : [...this.state.todos, {text: text}]
    })
  }

  render(){
    return(
      <div>
      <button onClick = {() => this.addTodo()}>Add Todo</button>
        <ul>
        {this.state.todos.map(todos => <Todo todo={todo} />)}
        </ul>
      </div>
    )
  }
}
//const rootElement = document.getElementById("root");
//ReactDOM.render(<App />, rootElement);
ReactDOM.render(<App />, document.getElementById("root"));